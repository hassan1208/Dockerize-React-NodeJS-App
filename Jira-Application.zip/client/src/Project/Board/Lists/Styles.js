import styled from 'styled-components';

export const Lists = styled.div`
  display: flex;
  margin: 26px -5px 0;
`;
